// خدمة بسيطة لتخزين الملفات الثابتة مؤقتًا وجعل التطبيق قابل للتثبيت (PWA)
const CACHE_NAME = "anon-messages-v1";
const ASSETS = [
  "./index.html",
  "./dashboard.html",
  "./inbox.html",
  "./my-sent.html",
  "./send.html",
  "./thread.html",
  "./style.css",
  "./app.js",
  "./firebase-config.js",
  "./manifest.json",
  "./icon-192.png",
  "./icon-512.png"
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(ASSETS)).catch(() => {})
  );
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

// لا نخزّن مؤقتًا أي اتصال بـ Firebase أو أي مصدر خارجي — فقط الملفات الثابتة لنفس الموقع
self.addEventListener("fetch", (event) => {
  const url = new URL(event.request.url);
  if (url.origin !== self.location.origin) return;

  event.respondWith(
    caches.match(event.request).then((cached) => {
      return (
        cached ||
        fetch(event.request)
          .then((res) => {
            const copy = res.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(event.request, copy));
            return res;
          })
          .catch(() => cached)
      );
    })
  );
});
