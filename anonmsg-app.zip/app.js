// ====================================================================
// الملف المشترك: تهيئة Firebase + دوال مساعدة تستخدمها كل الصفحات
// ====================================================================
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import {
  getAuth, GoogleAuthProvider, signInWithPopup, signOut,
  onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";
import {
  getFirestore, doc, setDoc, getDoc, collection, addDoc, query,
  where, orderBy, onSnapshot, serverTimestamp, updateDoc, limit
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

import { firebaseConfig } from "./firebase-config.js";

export const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);

export {
  GoogleAuthProvider, signInWithPopup, signOut, onAuthStateChanged,
  doc, setDoc, getDoc, collection, addDoc, query, where, orderBy,
  onSnapshot, serverTimestamp, updateDoc, limit
};

// -------------------- مساعدات عامة --------------------

export function showToast(msg) {
  let t = document.querySelector(".toast");
  if (!t) {
    t = document.createElement("div");
    t.className = "toast";
    document.body.appendChild(t);
  }
  t.textContent = msg;
  t.classList.add("show");
  clearTimeout(t._timer);
  t._timer = setTimeout(() => t.classList.remove("show"), 2200);
}

export function requireLogin(onUser) {
  return onAuthStateChanged(auth, (user) => {
    if (!user) {
      window.location.href = "index.html";
      return;
    }
    onUser(user);
  });
}

export async function ensureUserProfile(user) {
  // ينشئ (أو يحدّث) ملف تعريف عام بسيط عشان صفحة "الإرسال" تقدر تعرف اسم المستلم
  const ref = doc(db, "publicProfiles", user.uid);
  await setDoc(ref, {
    displayName: user.displayName || "مستخدم",
    photoURL: user.photoURL || "",
    updatedAt: serverTimestamp()
  }, { merge: true });
}

export function threadIdFor(ownerUid, senderUid) {
  return `${ownerUid}_${senderUid}`;
}

export function formatTime(ts) {
  if (!ts) return "";
  const d = ts.toDate ? ts.toDate() : new Date(ts);
  return d.toLocaleString("ar-EG", { hour: "2-digit", minute: "2-digit", day: "2-digit", month: "2-digit" });
}

export function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}
