// ====================================================================
// هذا الملف الوحيد اللي محتاج تعدله بعد إنشاء مشروع Firebase الخاص بك.
// روح لـ: Firebase Console > Project settings > عام > "تطبيقاتك" > أضف تطبيق ويب
// وهيعطيك كود شبيه بده، انسخه وحط القيم هنا بدل القيم الوهمية.
// ====================================================================
const firebaseConfig = {
  apiKey: "ضع-apiKey-هنا",
  authDomain: "ضع-authDomain-هنا",
  projectId: "ضع-projectId-هنا",
  storageBucket: "ضع-storageBucket-هنا",
  messagingSenderId: "ضع-messagingSenderId-هنا",
  appId: "ضع-appId-هنا"
};
